# AP COMPUTER Section II

## Class 1
1. This question involves creating a class named "RandomQuizes", the implementation of a generating random numbers by given min, max, and numberOfQuizes. For instance, if there are total 10 quiz files (quiz1.md, quiz2.md, ..., quiz10.md), and min=1, max=10. You want pick up 2 files (numberOfQuizes=2), the expected output should be something like:

    ```
        1, 3
    ```
if numberOfQuizes = 3, the output should like:

    ```
      3, 5, 8
    ```
No duplicated number should appear in the result.