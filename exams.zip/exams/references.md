# AP Computer Science A Exam 

## Free-Response Questions
[By Year](https://apstudents.collegeboard.org/courses/ap-computer-science-a/free-response-questions-by-year)