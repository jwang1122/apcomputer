
|Date|Students| Questions   | Time spent |wrong answer|
|---       |---     |---               |---         |---         |
|2021/01/23| Angela |section1:1~10     |15"29'      |1
|2021/-1/23| Nick   |section:1~10      |22"18       |1
|2021/01/30|Angela  | quiz1.pdf        |9"12        |1
|2021/01/30|Nick    | quiz1.pdf        |7"26        |1
|2021/02/06|Angela  | quiz2.md         |2"50        |2
|2021/02/06|Nick    | quiz2.md         |>5"         |1
|2021/02/06|Angela  | quiz3.pdf        |7"10        |0
|2021/02/06|Nick    | quiz3.pdf        |10"10       |1
|2021/02/06|Angela  | quiz4.pdf        |10"22       |3
|2021/02/06|Nick    | quiz4.pdf        |10"47       |2
|2021/02/20|Nick    | secion2-question3|20"         |80%
|2021/02/20|Nick    | quiz5.md         |6"23        |2
|2021/02/20|Nick    | quiz6.md         |19"43       |4
|2021/02/27|Angela  | quiz6.md         |10"42       |3
|2021/02/27|Nick    | quiz6.md         |10"02       |2
|2021/02/27|Angela  | secion2-question4|>30"        |not finish
|2021/02/27|Nick    | secion2-question4|>30"        |not finish
|2021/03/06|Angela  | secion2-question1，2|38"40    |1OK,2unfinished
|2021/03/06|Nick    | secion2-question1，2|35"11    |1,2 OK.
|2021/03/06|Angela  | quiz7.md         |11"38       |OK
|2021/03/06|Nick    | quiz7.md         |10"29       |3B by accident
|2021/03/06|Angela  | quiz8.md         |8"56        |2E,4C
|2021/03/06|Nick    | quiz8.md         |12"29       |2E,4E
|2021/03/13|Angela  | secion2-question4|            |absent
|2021/03/13|Nick    | secion2-question4|26"52       |50%
|2021/03/13|Angela  | quiz9.md         |            |absent
|2021/03/13|Nick    | quiz9.md         |9"30        |1E
|2021/03/13|Angela  | quiz10.md        |            |absent
|2021/03/13|Nick    | quiz10.md        |9"45        |2B,3A,5B
|2021/03/20|Angela  | quiz9.md         |12"52       |5D
|2021/03/20|Angela  | quiz10.md        |10"11       |1C,2B.3D
|2021/03/20|Angela  | secion2-question4|34"10       |90%
|2021/03/27|Nick    | quiz11.md        |            |4C
|2021/03/27|Angela  | quiz11.md        |5"35        |all right
|2021/03/27|Nick    | sectionII-1      |>30"        |40%
|2021/03/27|Angela  | sectionII-1      |            |no idea for part(b)
|2021/04/03|Nick    | sectionII-1      |24"51       |100%
|2021/04/03|Angela  | sectionII-1      |23"17       |100%
|2021/04/03|Nick    | quiz12.md        |12"33       |3D,5D
|2021/04/03|Angela  | quiz12.md        |9"04        |2B,3C,5A
|2021/04/03|Nick    | quiz13.md        |14"43       |2D,3C,4C,5D
|2021/04/03|Angela  | quiz13.md        |16"16       |2D,5D
|2021/04/10|Nick    | quiz1.md         |7"19        |1A,4E
|2021/04/10|Angela  | quiz1.md         |4"27        |100%
|2021/04/10|Nick    | sectionII-2.md   |28"13       |
|2021/04/10|Angela  | sectionII-2.md   |27"36       |70%
|2021/04/17|Nick    |    |      |absent
|2021/04/17|Angela  |quiz12.md         |5"23        |5A
|2021/04/17|Angela  |quiz3.md          |5"23        |5A
|2021/04/17|Angela  |sectionII-03.md   |>30"        |40%
|2021/04/24|Nick    |sectionII-04.md   |27"12       |95%
|2021/04/24|Angela  |sectionII-04.md   |24"21       |60%
|2021/04/24|Nick    |sectionII-03.md   |16"24       |
|2021/04/24|Angela  |sectionII-03.md   |17"45       |
|2021/05/01|Nick    |quiz12.md         |7"11        |3D,4C,5D
|2021/05/01|Angela  |quiz12.md         |8"2         |2C,3B,4E
|2021/05/01|Nick    |quiz14.md         |4"52        |100%
|2021/05/01|Angela  |quiz14.md         |7"12        |2E
|2021/05/01|Nick    |sectionII-09.md   |22"12       |
|2021/05/01|Angela  |sectionII-09.md   |23"41       |
|2021/05/08|Nick    |         |        |absent
|2021/05/08|Angela  |sectionII-09.md   |        |

